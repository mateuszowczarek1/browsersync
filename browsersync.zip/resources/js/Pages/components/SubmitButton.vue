<template>
    <button type="submit"
    class="bg-purple-900 text-white p-2 rounded-xl my-4 border-2 border-transparent hover:border-purple-100 transition-colors duration-300"><slot></slot></button>
</template>
