<template>
        <footer class="mt-8 bg-white/5 py-2 px-2 xl:flex justify-center rounded-xl mx-4 gap-8">
        <div>
            <h4 class="font-semibold"><i class="fa fa-github mx-2"></i> <a href="https://github.com/mateuszowczarek1">@mateuszowczarek1</a></h4>
        </div>
        <div>
            <h4><i class="fa fa-envelope mx-2"></i><a href="mailto:mateuszowczarek@onet.eu">mateuszowczarek@onet.eu</a></h4>
        </div>
    </footer>
</template>
