<template>
    <p class="text-xs text-purple-300 px-2 py-2 border-red-600"><slot></slot></p>
</template>
