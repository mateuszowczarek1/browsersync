<template>
    <div>
   <slot></slot>
</div>
</template>
